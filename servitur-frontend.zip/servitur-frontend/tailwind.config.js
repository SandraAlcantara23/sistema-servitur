/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        // Paleta oficial Servitur Gran Clas
        servitur: {
          rojo: '#C9252D',      // Rojo principal
          'rojo-hover': '#A91F27', // Hover
          azul: '#173F63',      // Azul marino principal
          'azul-oscuro': '#123451', // Menús / encabezados
          fondo: '#F4F5F6',     // Fondo general
          tarjeta: '#FFFFFF',   // Tarjetas
          texto: '#252525',     // Texto principal
          'texto-secundario': '#6B7280', // Texto secundario
        },
      },
      fontFamily: {
        display: ['"Dancing Script"', 'cursive'],
        sans: ['"Inter"', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
