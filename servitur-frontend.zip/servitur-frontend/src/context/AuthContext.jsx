import { createContext, useContext, useEffect, useState } from 'react'

const CLAVE_SESION = 'servitur_sesion'
const AuthContext = createContext(null)

// TODO: esto es una simulación de sesión 100% del lado del cliente, guardada
// en localStorage. Cuando exista el backend (Django REST Framework + JWT o
// sesiones), esto debe reemplazarse por tokens reales emitidos por el
// servidor tras validar usuario/contraseña — nunca confiar en el rol que
// el propio navegador dice tener.
export function AuthProvider({ children }) {
  const [sesion, setSesion] = useState(() => {
    try {
      const guardada = localStorage.getItem(CLAVE_SESION)
      return guardada ? JSON.parse(guardada) : null
    } catch {
      return null
    }
  })

  useEffect(() => {
    if (sesion) {
      localStorage.setItem(CLAVE_SESION, JSON.stringify(sesion))
    } else {
      localStorage.removeItem(CLAVE_SESION)
    }
  }, [sesion])

  const iniciarSesion = (datos) => setSesion(datos)
  const cerrarSesion = () => setSesion(null)

  return (
    <AuthContext.Provider value={{ sesion, iniciarSesion, cerrarSesion }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const contexto = useContext(AuthContext)
  if (!contexto) throw new Error('useAuth debe usarse dentro de <AuthProvider>')
  return contexto
}