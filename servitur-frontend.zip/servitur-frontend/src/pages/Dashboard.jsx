import AppLayout from '../components/layout/AppLayout.jsx'
import StatCard from '../components/dashboard/StatCard.jsx'
import WelcomeBanner from '../components/dashboard/WelcomeBanner.jsx'
import ProximosViajesCard from '../components/dashboard/ProximosViajesCard.jsx'
import TrackingCard from '../components/dashboard/TrackingCard.jsx'
import ViajesChartCard from '../components/dashboard/ViajesChartCard.jsx'
import IncidenciasRecientesCard from '../components/dashboard/IncidenciasRecientesCard.jsx'
import NoticiasCard from '../components/dashboard/NoticiasCard.jsx'
import {
  stats,
  proximosViajes,
  seguimientoResumen,
  resumenViajesSemana,
  noticias,
} from '../data/dashboardMock.js'

export default function Dashboard() {
  // TODO: reemplazar los datos de /src/data/dashboardMock.js por las respuestas reales del backend (Django REST Framework)
  return (
    <AppLayout>
      <div className="space-y-4 md:space-y-6">
        <WelcomeBanner userName="Sandra" />

        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          {stats.map((s) => (
            <StatCard key={s.key} stat={s} />
          ))}
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-[1.4fr_1fr] gap-4 md:gap-6">
          <ProximosViajesCard viajes={proximosViajes} />
          <TrackingCard resumen={seguimientoResumen} />
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-[1.2fr_1fr_1fr] gap-4 md:gap-6">
          <ViajesChartCard data={resumenViajesSemana} />
          <IncidenciasRecientesCard />
          <NoticiasCard noticias={noticias} />
        </div>
      </div>
    </AppLayout>
  )
}