import { useState } from 'react'
import { Users, Plus, Search, Pencil, Trash2, X, Check, ImageOff, FileDown, FileSpreadsheet } from 'lucide-react'
import AppLayout from '../components/layout/AppLayout.jsx'
import { unidades } from '../data/unidadesMock.js'
import { registrosAforo } from '../data/aforoMock.js'
import EmptyState from '../components/common/EmptyState.jsx'
import SelectorFotos from '../components/common/SelectorFotos.jsx'
import ConfirmDialog from '../components/common/ConfirmDialog.jsx'
import Toast from '../components/common/Toast.jsx'
import { useToast } from '../hooks/useToast.js'
import AforoReportePrintable from '../components/reports/AforoReportePrintable.jsx'
import { exportarComoPDF, exportarAforoAExcel } from '../utils/exportReports.js'
import { useBitacora } from '../hooks/useBitacora.js'

const FORM_VACIO = { fecha: '', unidadEco: '', turno: '', aforo: '', fotos: [] }
const MES_ACTUAL = new Date().toISOString().slice(0, 7)

const TURNOS = [
  'Primer turno entrada',
  'Primer turno salida',
  'Segundo turno entrada',
  'Segundo turno salida',
  'Tercer turno entrada',
  'Tercer turno salida',
  'Turno mixto entrada',
  'Turno mixto salida',
]

export default function Operaciones() {
  const [registros, setRegistros] = useState(registrosAforo)
  const [busqueda, setBusqueda] = useState('')
  const [mostrarForm, setMostrarForm] = useState(false)
  const [nuevo, setNuevo] = useState(FORM_VACIO)
  const [editandoId, setEditandoId] = useState(null)
  const [formEdicion, setFormEdicion] = useState({})
  const [mesReporte, setMesReporte] = useState(MES_ACTUAL)
  const [turnosSeleccionados, setTurnosSeleccionados] = useState(TURNOS)
  const [registroAEliminar, setRegistroAEliminar] = useState(null)
  const { toast, mostrarToast, cerrarToast } = useToast()
  const { registrar } = useBitacora()

  const filtrados = registros
    .filter(
      (r) =>
        r.ruta.toLowerCase().includes(busqueda.trim().toLowerCase()) ||
        r.unidadEco.includes(busqueda.trim()),
    )
    .sort((a, b) => b.fecha.localeCompare(a.fecha))

  const registrosDelMes = registros
    .filter((r) => r.fecha.startsWith(mesReporte) && turnosSeleccionados.includes(r.turno))
    .sort((a, b) => a.fecha.localeCompare(b.fecha))

  const mesLabel = (() => {
    const [anio, mes] = mesReporte.split('-')
    return new Date(Number(anio), Number(mes) - 1, 1).toLocaleDateString('es-MX', {
      month: 'long',
      year: 'numeric',
    })
  })()

  const turnosLabel =
    turnosSeleccionados.length === TURNOS.length
      ? 'Todos los turnos'
      : turnosSeleccionados.length === 0
        ? 'Ninguno seleccionado'
        : turnosSeleccionados.join(', ')

  const alternarTurno = (turno) => {
    setTurnosSeleccionados((prev) =>
      prev.includes(turno) ? prev.filter((t) => t !== turno) : [...prev, turno],
    )
  }

  const descargarPDFMes = () => {
    setTimeout(() => exportarComoPDF(`aforo-${mesReporte}.pdf`), 250)
  }

  const descargarExcelMes = () => {
    exportarAforoAExcel(registrosDelMes, `aforo-${mesReporte}.xlsx`, mesLabel, turnosLabel)
  }

  const unidadSeleccionada = unidades.find((u) => u.eco === nuevo.unidadEco)

  const registrarAforo = (e) => {
    e.preventDefault()
    const unidad = unidades.find((u) => u.eco === nuevo.unidadEco)
    if (!unidad) return

    if (Number(nuevo.aforo) < 0) {
      mostrarToast('El aforo no puede ser negativo.', 'error')
      return
    }

    const nuevoId = Math.max(0, ...registrosAforo.map((r) => r.id)) + 1
    const registro = {
      id: nuevoId,
      fecha: nuevo.fecha,
      unidadEco: unidad.eco,
      ruta: unidad.ruta,
      conductor: unidad.conductorActual,
      turno: nuevo.turno,
      aforo: Number(nuevo.aforo),
      fotos: nuevo.fotos,
    }
    registrosAforo.push(registro)
    setRegistros([...registrosAforo])
    setNuevo(FORM_VACIO)
    setMostrarForm(false)
    mostrarToast('Aforo registrado correctamente.')
    registrar('crear', 'Aforo', `Registró aforo de ${registro.aforo} pasajeros en unidad ${registro.unidadEco} (${registro.turno}, ${registro.fecha})`)
  }

  const iniciarEdicion = (r) => {
    setFormEdicion({ fecha: r.fecha, turno: r.turno, aforo: r.aforo })
    setEditandoId(r.id)
  }

  const cancelarEdicion = () => setEditandoId(null)

  const guardarEdicion = (r) => {
    if (Number(formEdicion.aforo) < 0) {
      mostrarToast('El aforo no puede ser negativo.', 'error')
      return
    }
    Object.assign(r, {
      fecha: formEdicion.fecha,
      turno: formEdicion.turno,
      aforo: Number(formEdicion.aforo),
    })
    setEditandoId(null)
    setRegistros([...registrosAforo])
    mostrarToast('Registro actualizado correctamente.')
    registrar('actualizar', 'Aforo', `Actualizó el registro de aforo del ${r.fecha} en unidad ${r.unidadEco} (ahora ${r.aforo} pasajeros)`)
  }

  const pedirConfirmacionEliminar = (r) => setRegistroAEliminar(r)

  const cancelarEliminar = () => setRegistroAEliminar(null)

  const confirmarEliminar = () => {
    const idx = registrosAforo.findIndex((x) => x.id === registroAEliminar.id)
    if (idx !== -1) registrosAforo.splice(idx, 1)
    setRegistros([...registrosAforo])
    registrar('eliminar', 'Aforo', `Eliminó el registro de aforo del ${registroAEliminar.fecha} en unidad ${registroAEliminar.unidadEco}`)
    setRegistroAEliminar(null)
    mostrarToast('Registro eliminado.')
  }

  const totalAforo = filtrados.reduce((acc, r) => acc + r.aforo, 0)

  return (
    <AppLayout>
      <div className="space-y-4 md:space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h1 className="flex items-center gap-2 text-xl font-semibold text-servitur-texto">
              <Users className="w-5 h-5 text-servitur-azul" />
              Aforo por ruta
            </h1>
            <p className="text-sm text-servitur-texto-secundario mt-0.5">
              Registro manual del conductor/operador: pasajeros acumulados por ruta y fecha.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-2 border border-servitur-texto-secundario/30 rounded-lg px-3 py-2 bg-servitur-tarjeta">
              <Search className="w-4 h-4 text-servitur-texto-secundario" />
              <input
                type="text"
                value={busqueda}
                onChange={(e) => setBusqueda(e.target.value)}
                placeholder="Buscar por ruta o ECO..."
                className="outline-none text-sm bg-transparent w-44"
              />
            </div>
            <button
              onClick={() => setMostrarForm(!mostrarForm)}
              className="flex items-center gap-1.5 text-sm bg-servitur-azul hover:opacity-90 text-white px-3 py-2 rounded-lg"
            >
              <Plus className="w-4 h-4" />
              Registrar aforo
            </button>
          </div>
        </div>

        <div className="bg-servitur-tarjeta rounded-xl shadow-sm border border-servitur-texto-secundario/10 p-4 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div className="flex items-center gap-2">
              <label className="text-sm text-servitur-texto-secundario">Reporte mensual:</label>
              <input
                type="month"
                value={mesReporte}
                onChange={(e) => setMesReporte(e.target.value)}
                className="border border-servitur-texto-secundario/30 rounded-lg px-3 py-2 text-sm outline-none focus:border-servitur-azul"
              />
              <span className="text-xs text-servitur-texto-secundario hidden sm:inline">
                {registrosDelMes.length} registro{registrosDelMes.length === 1 ? '' : 's'}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={descargarPDFMes}
                disabled={registrosDelMes.length === 0}
                className="flex items-center gap-1.5 text-sm border border-servitur-azul text-servitur-azul px-3 py-2 rounded-lg hover:bg-servitur-azul/5 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-transparent"
              >
                <FileDown className="w-4 h-4" /> Descargar PDF
              </button>
              <button
                onClick={descargarExcelMes}
                disabled={registrosDelMes.length === 0}
                className="flex items-center gap-1.5 text-sm border border-servitur-azul text-servitur-azul px-3 py-2 rounded-lg hover:bg-servitur-azul/5 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-transparent"
              >
                <FileSpreadsheet className="w-4 h-4" /> Descargar Excel
              </button>
            </div>
          </div>

          <div className="border-t border-servitur-texto-secundario/10 pt-3">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs font-medium text-servitur-texto-secundario">Turnos a incluir en el reporte:</p>
              <div className="flex items-center gap-3 text-xs">
                <button
                  type="button"
                  onClick={() => setTurnosSeleccionados(TURNOS)}
                  className="text-servitur-azul hover:underline"
                >
                  Seleccionar todos
                </button>
                <button
                  type="button"
                  onClick={() => setTurnosSeleccionados([])}
                  className="text-servitur-texto-secundario hover:underline"
                >
                  Ninguno
                </button>
              </div>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-x-4 gap-y-2">
              {TURNOS.map((t) => (
                <label key={t} className="flex items-center gap-2 text-sm text-servitur-texto cursor-pointer">
                  <input
                    type="checkbox"
                    checked={turnosSeleccionados.includes(t)}
                    onChange={() => alternarTurno(t)}
                    className="accent-servitur-azul w-4 h-4"
                  />
                  {t}
                </label>
              ))}
            </div>
          </div>
        </div>
          {mostrarForm && (
          <form
            onSubmit={registrarAforo}
            className="bg-servitur-tarjeta rounded-xl shadow-sm border border-servitur-texto-secundario/10 p-4 md:p-6 grid grid-cols-1 sm:grid-cols-2 gap-4"
          >
            <div>
              <label className="block text-sm font-medium text-servitur-texto mb-1">Fecha</label>
              <input
                required
                type="date"
                value={nuevo.fecha}
                onChange={(e) => setNuevo({ ...nuevo, fecha: e.target.value })}
                className="w-full border border-servitur-texto-secundario/30 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-servitur-azul"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-servitur-texto mb-1">Unidad</label>
              <select
                required
                value={nuevo.unidadEco}
                onChange={(e) => setNuevo({ ...nuevo, unidadEco: e.target.value })}
                className="w-full border border-servitur-texto-secundario/30 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-servitur-azul"
              >
                <option value="" disabled>Selecciona una unidad</option>
                {unidades.map((u) => (
                  <option key={u.id} value={u.eco}>
                    {u.eco} — {u.ruta}
                  </option>
                ))}
              </select>
            </div>

            {unidadSeleccionada && (
              <div className="sm:col-span-2 -mt-2 text-xs text-servitur-texto-secundario">
                Ruta: <span className="font-medium text-servitur-texto">{unidadSeleccionada.ruta}</span>
                {' · '}
                Conductor: <span className="font-medium text-servitur-texto">{unidadSeleccionada.conductorActual}</span>
              </div>
            )}

            <div className="sm:col-span-2">
              <label className="block text-sm font-medium text-servitur-texto mb-1">Turno</label>
              <select
                required
                value={nuevo.turno}
                onChange={(e) => setNuevo({ ...nuevo, turno: e.target.value })}
                className="w-full border border-servitur-texto-secundario/30 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-servitur-azul"
              >
                <option value="" disabled>Selecciona un turno</option>
                {TURNOS.map((t) => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-servitur-texto mb-1">Aforo (pasajeros)</label>
              <input
                required
                type="number"
                min="0"
                value={nuevo.aforo}
                onChange={(e) => setNuevo({ ...nuevo, aforo: e.target.value })}
                className="w-full border border-servitur-texto-secundario/30 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-servitur-azul"
              />
            </div>

            <div className="sm:col-span-2">
              <SelectorFotos
                fotos={nuevo.fotos}
                setFotos={(actualizador) =>
                  setNuevo((prev) => ({
                    ...prev,
                    fotos: typeof actualizador === 'function' ? actualizador(prev.fotos) : actualizador,
                  }))
                }
                label="Foto del aforo (opcional) — ej. conteo, tablero o boletaje"
              />
            </div>

            <div className="sm:col-span-2 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => {
                  setNuevo(FORM_VACIO)
                  setMostrarForm(false)
                }}
                className="text-sm text-servitur-texto-secundario hover:underline"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="bg-servitur-azul hover:opacity-90 text-white text-sm font-medium px-5 py-2.5 rounded-lg"
              >
                Guardar registro
              </button>
            </div>
          </form>
        )}

        <div className="bg-servitur-tarjeta rounded-xl shadow-sm border border-servitur-texto-secundario/10 overflow-x-auto">
          {filtrados.length === 0 ? (
            <EmptyState
              titulo="Sin registros de aforo"
              descripcion={
                busqueda
                  ? `No hay registros que coincidan con "${busqueda}".`
                  : 'Aún no se ha registrado ningún aforo.'
              }
              onLimpiar={() => setBusqueda('')}
            />
          ) : (
            <>
              <table className="w-full text-sm min-w-[760px]">
                <thead>
                  <tr className="text-left text-servitur-texto-secundario border-b border-servitur-texto-secundario/15">
                    <th className="font-medium py-3 px-4">Fecha</th>
                    <th className="font-medium py-3 px-2">Ruta</th>
                    <th className="font-medium py-3 px-2">Unidad</th>
                    <th className="font-medium py-3 px-2 hidden sm:table-cell">Conductor</th>
                    <th className="font-medium py-3 px-2 hidden md:table-cell">Turno</th>
                    <th className="font-medium py-3 px-2">Aforo</th>
                    <th className="font-medium py-3 px-2 hidden sm:table-cell">Foto</th>
                    <th className="font-medium py-3 px-4">Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {filtrados.map((r) => {
                    const enEdicion = editandoId === r.id
                    return (
                      <tr key={r.id} className="border-b border-servitur-texto-secundario/10 last:border-0 hover:bg-servitur-fondo">
                        <td className="py-2.5 px-4 text-servitur-texto">
                          {enEdicion ? (
                            <input
                              type="date"
                              value={formEdicion.fecha}
                              onChange={(e) => setFormEdicion({ ...formEdicion, fecha: e.target.value })}
                              className="w-36 border border-servitur-azul/40 rounded px-1.5 py-1 text-sm outline-none focus:border-servitur-azul"
                            />
                          ) : (
                            r.fecha
                          )}
                        </td>
                        <td className="py-2.5 px-2 text-servitur-texto-secundario">{r.ruta}</td>
                        <td className="py-2.5 px-2 text-servitur-texto-secundario">{r.unidadEco}</td>
                        <td className="py-2.5 px-2 text-servitur-texto-secundario hidden sm:table-cell">{r.conductor}</td>
                        <td className="py-2.5 px-2 text-servitur-texto-secundario hidden md:table-cell">
                          {enEdicion ? (
                            <select
                              value={formEdicion.turno}
                              onChange={(e) => setFormEdicion({ ...formEdicion, turno: e.target.value })}
                              className="w-40 border border-servitur-azul/40 rounded px-1.5 py-1 text-sm outline-none focus:border-servitur-azul"
                            >
                              {TURNOS.map((t) => (
                                <option key={t} value={t}>{t}</option>
                              ))}
                            </select>
                          ) : (
                            r.turno
                          )}
                        </td>
                        <td className="py-2.5 px-2 font-medium text-servitur-texto">
                          {enEdicion ? (
                            <input
                              type="number"
                              min="0"
                              value={formEdicion.aforo}
                              onChange={(e) => setFormEdicion({ ...formEdicion, aforo: e.target.value })}
                              className="w-20 border border-servitur-azul/40 rounded px-1.5 py-1 text-sm outline-none focus:border-servitur-azul"
                            />
                          ) : (
                            r.aforo
                          )}
                        </td>
                        <td className="py-2.5 px-2 hidden sm:table-cell">
                          {r.fotos && r.fotos.length > 0 ? (
                            <a href={r.fotos[0].url} target="_blank" rel="noopener noreferrer" className="relative inline-block">
                              <img
                                src={r.fotos[0].url}
                                alt="Evidencia de aforo"
                                className="w-10 h-10 object-cover rounded-lg border border-servitur-texto-secundario/15"
                              />
                              {r.fotos.length > 1 && (
                                <span className="absolute -top-1.5 -right-1.5 bg-servitur-azul text-white text-[10px] rounded-full w-4 h-4 flex items-center justify-center">
                                  +{r.fotos.length - 1}
                                </span>
                              )}
                            </a>
                          ) : (
                            <ImageOff className="w-4 h-4 text-servitur-texto-secundario/40" />
                          )}
                        </td>
                        <td className="py-2.5 px-4">
                          {enEdicion ? (
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => guardarEdicion(r)}
                                title="Guardar"
                                className="flex items-center gap-1 text-xs text-green-700 hover:underline"
                              >
                                <Check className="w-3.5 h-3.5" /> Guardar
                              </button>
                              <button
                                onClick={cancelarEdicion}
                                title="Cancelar"
                                className="flex items-center gap-1 text-xs text-servitur-texto-secundario hover:underline"
                              >
                                <X className="w-3.5 h-3.5" /> Cancelar
                              </button>
                            </div>
                          ) : (
                            <div className="flex items-center gap-3">
                              <button
                                onClick={() => iniciarEdicion(r)}
                                title="Editar"
                                className="flex items-center gap-1 text-xs text-servitur-azul hover:underline"
                              >
                                <Pencil className="w-3.5 h-3.5" /> Editar
                              </button>
                              <button
                                onClick={() => pedirConfirmacionEliminar(r)}
                                title="Eliminar"
                                className="flex items-center gap-1 text-xs text-servitur-rojo hover:underline"
                              >
                                <Trash2 className="w-3.5 h-3.5" /> Eliminar
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
              <div className="border-t border-servitur-texto-secundario/10 px-4 py-3 text-sm text-servitur-texto-secundario">
                Total acumulado{busqueda ? ' en esta búsqueda' : ''}:{' '}
                <span className="font-medium text-servitur-texto">
                  {totalAforo.toLocaleString('es-MX')} pasajeros
                </span>
              </div>
            </>
          )}
        </div>
      </div>

      <div className="print-area">
        <AforoReportePrintable registros={registrosDelMes} mesLabel={mesLabel} turnosLabel={turnosLabel} />
      </div>

      <ConfirmDialog
        abierto={Boolean(registroAEliminar)}
        titulo="Eliminar registro de aforo"
        mensaje={
          registroAEliminar
            ? `Se eliminará el registro del ${registroAEliminar.fecha} (unidad ${registroAEliminar.unidadEco}, ${registroAEliminar.aforo} pasajeros). Esta acción no se puede deshacer.`
            : ''
        }
        textoConfirmar="Sí, eliminar"
        peligro
        onConfirmar={confirmarEliminar}
        onCancelar={cancelarEliminar}
      />

      <Toast toast={toast} onClose={cerrarToast} />
    </AppLayout>
  )
}