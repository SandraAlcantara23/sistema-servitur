import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Settings, Lock, User, Palette, ShieldCheck, Copy, RefreshCw, Check, Bell, Monitor, Users } from 'lucide-react'
import AppLayout from '../components/layout/AppLayout.jsx'
import { obtenerCodigoSupervisor, guardarCodigoSupervisor, generarCodigoAleatorio } from '../utils/supervisorCode.js'
import { conductores } from '../data/conductoresMock.js'
import { useAuth } from '../context/AuthContext.jsx'
import { seccionConfigPermitida, paginaPermitida, EVENTO_REQUIERE_PAGINA } from '../utils/rolesPermisos.js'

const TEMAS = [
  { nombre: 'Rojo Servitur (predeterminado)', color: '#C9252D' },
  { nombre: 'Azul marino', color: '#173F63' },
]

const EVENTOS_NOTIFICACION = [
  { id: 'permiso', label: 'Nueva solicitud de permiso' },
  { id: 'incidencia', label: 'Incidencia registrada' },
  { id: 'retraso', label: 'Retraso reportado' },
  { id: 'reporteConductor', label: 'Nuevo Reporte del Conductor guardado' },
]

const SESIONES_RECIENTES = [
  { fecha: '14/09/2026 09:12', dispositivo: 'Chrome en Windows', ubicacion: 'Jilotepec, Edo. Méx.' },
  { fecha: '13/09/2026 18:40', dispositivo: 'Chrome en Android', ubicacion: 'Jilotepec, Edo. Méx.' },
  { fecha: '12/09/2026 08:05', dispositivo: 'Chrome en Windows', ubicacion: 'Jilotepec, Edo. Méx.' },
]

export default function Configuracion() {
  const { sesion } = useAuth()
  const rolActualUsuario = sesion?.rol
  const [temaSeleccionado, setTemaSeleccionado] = useState(TEMAS[0].nombre)
  const [codigoSupervisor, setCodigoSupervisor] = useState(obtenerCodigoSupervisor())
  const [copiado, setCopiado] = useState(false)
  const [notificaciones, setNotificaciones] = useState(
    Object.fromEntries(EVENTOS_NOTIFICACION.map((e) => [e.id, { sistema: true, correo: false }])),
  )

  const eventosNotificacionVisibles = EVENTOS_NOTIFICACION.filter((e) =>
    paginaPermitida(rolActualUsuario, EVENTO_REQUIERE_PAGINA[e.id]),
  )

  const regenerarCodigo = () => {
    const nuevo = generarCodigoAleatorio()
    setCodigoSupervisor(nuevo)
    guardarCodigoSupervisor(nuevo)
  }

  const copiarCodigo = () => {
    navigator.clipboard.writeText(codigoSupervisor)
    setCopiado(true)
    setTimeout(() => setCopiado(false), 1500)
  }

  const alternarNotificacion = (id, canal) => {
    setNotificaciones((prev) => ({
      ...prev,
      [id]: { ...prev[id], [canal]: !prev[id][canal] },
    }))
  }

  const conteoRoles = {
    Administrador: 2,
    Supervisor: 3,
    Monitoreo: 2,
    RH: 2,
    Conductor: conductores.length,
  }

  return (
    <AppLayout>
      <div className="space-y-4 md:space-y-6 max-w-2xl mx-auto"> 
        <div>
          <h1 className="flex items-center gap-2 text-xl font-semibold text-servitur-texto">
            <Settings className="w-5 h-5 text-servitur-azul" />
            Configuración
          </h1>
          <p className="text-sm text-servitur-texto-secundario mt-0.5">
            Ajustes de tu cuenta y de la plataforma.
          </p>
        </div>

        {/* Datos de usuario */}
        {seccionConfigPermitida(rolActualUsuario, 'datosUsuario') && (
        <div className="bg-servitur-tarjeta rounded-xl shadow-sm border border-servitur-texto-secundario/10 p-4 md:p-6">
          <h2 className="flex items-center gap-2 font-semibold text-servitur-texto mb-4">
            <User className="w-4 h-4 text-servitur-azul" />
            Datos de usuario
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-servitur-texto mb-1">Nombre de usuario</label>
              <input
                type="text"
                defaultValue={sesion?.nombre ?? ''}
                className="w-full border border-servitur-texto-secundario/30 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-servitur-azul"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-servitur-texto mb-1">Correo electrónico</label>
              <input
                type="email"
                defaultValue={sesion?.correo ?? ''}
                placeholder="correo@servitur.com"
                className="w-full border border-servitur-texto-secundario/30 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-servitur-azul"
              />
            </div>
          </div>
          <button className="mt-4 text-sm bg-servitur-azul text-white px-4 py-2 rounded-lg hover:opacity-90">
            Guardar cambios
          </button>
        </div>
        )}

        {/* Cambio de contraseña */}
        {seccionConfigPermitida(rolActualUsuario, 'contrasena') && (
        <div className="bg-servitur-tarjeta rounded-xl shadow-sm border border-servitur-texto-secundario/10 p-4 md:p-6">
          <h2 className="flex items-center gap-2 font-semibold text-servitur-texto mb-4">
            <Lock className="w-4 h-4 text-servitur-azul" />
            Cambiar contraseña
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-servitur-texto mb-1">Contraseña actual</label>
              <input
                type="password"
                className="w-full border border-servitur-texto-secundario/30 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-servitur-azul"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-servitur-texto mb-1">Nueva contraseña</label>
              <input
                type="password"
                className="w-full border border-servitur-texto-secundario/30 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-servitur-azul"
              />
            </div>
          </div>
          <button className="mt-4 text-sm bg-servitur-azul text-white px-4 py-2 rounded-lg hover:opacity-90">
            Actualizar contraseña
          </button>
        </div>
        )}

        {/* Código de autorización de Supervisor */}
        {seccionConfigPermitida(rolActualUsuario, 'codigoSupervisor') && (
        <div className="bg-servitur-tarjeta rounded-xl shadow-sm border border-servitur-texto-secundario/10 p-4 md:p-6">
          <h2 className="flex items-center gap-2 font-semibold text-servitur-texto mb-1">
            <ShieldCheck className="w-4 h-4 text-servitur-azul" />
            Código de autorización de Supervisor
          </h2>
          <p className="text-sm text-servitur-texto-secundario mb-4">
            Compártelo solo con las personas que deban registrarse como Supervisor. Cualquiera con este código puede crear una cuenta con ese rol.
          </p>

          <div className="flex flex-col sm:flex-row sm:items-center gap-3">
            <div className="flex-1 flex items-center justify-between border border-servitur-texto-secundario/30 rounded-lg px-3 py-2.5 bg-servitur-fondo">
              <span className="font-mono text-sm text-servitur-texto tracking-wide">{codigoSupervisor}</span>
              <button
                onClick={copiarCodigo}
                className="flex items-center gap-1 text-xs text-servitur-azul hover:underline shrink-0"
              >
                {copiado ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copiado ? 'Copiado' : 'Copiar'}
              </button>
            </div>
            <button
              onClick={regenerarCodigo}
              className="flex items-center gap-1.5 text-sm bg-servitur-azul text-white px-4 py-2.5 rounded-lg hover:opacity-90 shrink-0"
            >
              <RefreshCw className="w-4 h-4" />
              Generar nuevo código
            </button>
          </div>

          <p className="text-xs text-servitur-texto-secundario mt-3">
            Al generar uno nuevo, el código anterior deja de funcionar de inmediato.
          </p>
        </div>
        )}

        {/* Notificaciones */}
        {seccionConfigPermitida(rolActualUsuario, 'notificaciones') && (
        <div className="bg-servitur-tarjeta rounded-xl shadow-sm border border-servitur-texto-secundario/10 p-4 md:p-6">
          <h2 className="flex items-center gap-2 font-semibold text-servitur-texto mb-1">
            <Bell className="w-4 h-4 text-servitur-azul" />
            Notificaciones
          </h2>
          <p className="text-sm text-servitur-texto-secundario mb-4">
            Elige qué avisos quieres recibir y por dónde.
          </p>

          <div className="space-y-1">
            <div className="grid grid-cols-[1fr_auto_auto] gap-3 text-xs font-medium text-servitur-texto-secundario pb-2 border-b border-servitur-texto-secundario/15">
              <span>Evento</span>
              <span className="w-16 text-center">Sistema</span>
              <span className="w-16 text-center">Correo</span>
            </div>
            {eventosNotificacionVisibles.map((evento) => (
              <div key={evento.id} className="grid grid-cols-[1fr_auto_auto] gap-3 items-center py-2 border-b border-servitur-texto-secundario/10 last:border-0">
                <span className="text-sm text-servitur-texto">{evento.label}</span>
                <span className="w-16 flex justify-center">
                  <input
                    type="checkbox"
                    checked={notificaciones[evento.id].sistema}
                    onChange={() => alternarNotificacion(evento.id, 'sistema')}
                  />
                </span>
                <span className="w-16 flex justify-center">
                  <input
                    type="checkbox"
                    checked={notificaciones[evento.id].correo}
                    onChange={() => alternarNotificacion(evento.id, 'correo')}
                  />
                </span>
              </div>
            ))}
          </div>

          <button className="mt-4 text-sm bg-servitur-azul text-white px-4 py-2 rounded-lg hover:opacity-90">
            Guardar preferencias
          </button>
        </div>
        )}

        {/* Sesión y seguridad */}
        {seccionConfigPermitida(rolActualUsuario, 'sesionSeguridad') && (
        <div className="bg-servitur-tarjeta rounded-xl shadow-sm border border-servitur-texto-secundario/10 p-4 md:p-6">
          <h2 className="flex items-center gap-2 font-semibold text-servitur-texto mb-1">
            <Monitor className="w-4 h-4 text-servitur-azul" />
            Sesión y seguridad
          </h2>
          <p className="text-sm text-servitur-texto-secundario mb-4">
            Revisa dónde has iniciado sesión y ciérralas si algo se ve raro.
          </p>

          <ul className="space-y-2 mb-4">
            {SESIONES_RECIENTES.map((s, i) => (
              <li key={i} className="flex items-center justify-between text-sm border border-servitur-texto-secundario/15 rounded-lg px-3 py-2">
                <div>
                  <p className="text-servitur-texto">{s.dispositivo}</p>
                  <p className="text-xs text-servitur-texto-secundario">{s.ubicacion}</p>
                </div>
                <span className="text-xs text-servitur-texto-secundario">{s.fecha}</span>
              </li>
            ))}
          </ul>
          <p className="text-xs text-servitur-texto-secundario mb-3">
            Esta lista es de ejemplo — cuando esté conectado el backend, mostrará tus inicios de sesión reales.
          </p>

          <button className="text-sm border border-servitur-rojo text-servitur-rojo px-4 py-2 rounded-lg hover:bg-servitur-rojo/5">
            Cerrar sesión en todos los dispositivos
          </button>
        </div>
        )}

        {/* Gestión de roles — solo visible para Administrador */}
        {seccionConfigPermitida(rolActualUsuario, 'gestionRoles') && (
          <div className="bg-servitur-tarjeta rounded-xl shadow-sm border border-servitur-texto-secundario/10 p-4 md:p-6">
            <h2 className="flex items-center gap-2 font-semibold text-servitur-texto mb-1">
              <Users className="w-4 h-4 text-servitur-azul" />
              Gestión de roles
            </h2>
            <p className="text-sm text-servitur-texto-secundario mb-4">
              Cuántas cuentas hay por rol en el sistema.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
              {Object.entries(conteoRoles).map(([rol, cantidad]) => (
                <div key={rol} className="border border-servitur-texto-secundario/15 rounded-lg px-3 py-2.5 text-center">
                  <p className="text-lg font-semibold text-servitur-texto">{cantidad}</p>
                  <p className="text-xs text-servitur-texto-secundario">{rol}</p>
                </div>
              ))}
            </div>

            <Link to="/usuarios" className="text-sm text-servitur-azul hover:underline">
              Ver todos los usuarios →
            </Link>
          </div>
        )}

        {/* Apariencia */}
        {seccionConfigPermitida(rolActualUsuario, 'apariencia') && (
        <div className="bg-servitur-tarjeta rounded-xl shadow-sm border border-servitur-texto-secundario/10 p-4 md:p-6">
          <h2 className="flex items-center gap-2 font-semibold text-servitur-texto mb-4">
            <Palette className="w-4 h-4 text-servitur-azul" />
            Apariencia
          </h2>
          <div className="space-y-2">
            {TEMAS.map((t) => (
              <label
                key={t.nombre}
                className="flex items-center gap-3 border border-servitur-texto-secundario/20 rounded-lg px-3 py-2.5 cursor-pointer hover:bg-servitur-fondo"
              >
                <input
                  type="radio"
                  name="tema"
                  checked={temaSeleccionado === t.nombre}
                  onChange={() => setTemaSeleccionado(t.nombre)}
                />
                <span className="w-4 h-4 rounded-full" style={{ backgroundColor: t.color }} />
                <span className="text-sm text-servitur-texto">{t.nombre}</span>
              </label>
            ))}
          </div>
          <p className="text-xs text-servitur-texto-secundario mt-3">
            El cambio de tema todavía no está conectado a los estilos globales — se guarda la preferencia visualmente por ahora.
          </p>
        </div>
        )}
      </div>
    </AppLayout>
  )
}