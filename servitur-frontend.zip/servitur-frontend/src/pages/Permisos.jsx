import { useState } from 'react'
import { Link } from 'react-router-dom'
import {
  ClipboardList, Check, X as XIcon, Plus, Pencil, Lock, Search,
  Paperclip, FileDown, FileSpreadsheet,
} from 'lucide-react'
import AppLayout from '../components/layout/AppLayout.jsx'
import IncidenciasPanel from '../components/permisos/IncidenciasPanel.jsx'
import PermisosListPrintable from '../components/reports/PermisosListPrintable.jsx'
import { solicitudesIniciales } from '../data/permisosMock.js'
import { conductores } from '../data/conductoresMock.js'
import { exportarComoPDF, exportarAExcel } from '../utils/exportReports.js'
import EmptyState from '../components/common/EmptyState.jsx'
import { useAuth } from '../context/AuthContext.jsx'
import { useBitacora } from '../hooks/useBitacora.js'

const ROLES_CON_PERMISO = ['RH', 'Administrador', 'Supervisor']

const ESTATUS_STYLES = {
  Pendiente: 'bg-amber-100 text-amber-700',
  Aprobado: 'bg-green-100 text-green-700',
  Rechazado: 'bg-red-100 text-red-700',
}

const ESTATUS_FILTRO = ['Todos', 'Pendiente', 'Aprobado', 'Rechazado']

export default function Permisos() {
  const [tab, setTab] = useState('solicitudes')
  const [solicitudes, setSolicitudes] = useState(solicitudesIniciales)
  const [mostrarForm, setMostrarForm] = useState(false)
  const [nuevo, setNuevo] = useState({ conductor: '', tipo: 'Permiso personal', fechaInicio: '', fechaFin: '', motivo: '' })
  const [documento, setDocumento] = useState(null)
  const [editandoId, setEditandoId] = useState(null)
  const [rechazandoId, setRechazandoId] = useState(null)
  const [comentarioRechazo, setComentarioRechazo] = useState('')
  const [filtroConductor, setFiltroConductor] = useState('')
  const [filtroEstatus, setFiltroEstatus] = useState('Todos')
  const [errorSolicitud, setErrorSolicitud] = useState('')

  const { sesion } = useAuth()
  const rolActual = sesion?.rol
  const esConductor = rolActual === 'Conductor'
  const { registrar } = useBitacora()
  const puedeGestionar = ROLES_CON_PERMISO.includes(rolActual)

  // Si es Conductor, solo ve sus propias solicitudes; el resto de roles con
  // acceso a esta pantalla ve todas.
  const solicitudesVisibles = esConductor
    ? solicitudes.filter((s) => s.conductor === sesion?.nombre)
    : solicitudes

  const solicitudesFiltradas = solicitudesVisibles.filter((s) => {
    const coincideConductor = s.conductor.toLowerCase().includes(filtroConductor.trim().toLowerCase())
    const coincideEstatus = filtroEstatus === 'Todos' || s.estatus === filtroEstatus
    return coincideConductor && coincideEstatus
  })

  const conteo = {
    Pendiente: solicitudesVisibles.filter((s) => s.estatus === 'Pendiente').length,
    Aprobado: solicitudesVisibles.filter((s) => s.estatus === 'Aprobado').length,
    Rechazado: solicitudesVisibles.filter((s) => s.estatus === 'Rechazado').length,
  }

  const aprobar = (id) => {
    const solicitud = solicitudes.find((s) => s.id === id)
    setSolicitudes((prev) => prev.map((s) => (s.id === id ? { ...s, estatus: 'Aprobado', comentarioRH: '' } : s)))
    setEditandoId(null)
    if (solicitud) registrar('aprobar', 'Permisos', `Aprobó ${solicitud.tipo} de ${solicitud.conductor} (${solicitud.fechaInicio} a ${solicitud.fechaFin})`)
  }

  const iniciarRechazo = (id) => {
    setRechazandoId(id)
    setComentarioRechazo('')
  }

  const confirmarRechazo = (id) => {
    const solicitud = solicitudes.find((s) => s.id === id)
    setSolicitudes((prev) => prev.map((s) => (s.id === id ? { ...s, estatus: 'Rechazado', comentarioRH: comentarioRechazo } : s)))
    setRechazandoId(null)
    setEditandoId(null)
    if (solicitud) registrar('rechazar', 'Permisos', `Rechazó ${solicitud.tipo} de ${solicitud.conductor} (${solicitud.fechaInicio} a ${solicitud.fechaFin})`)
  }

  const buscarIdConductor = (nombre) => conductores.find((c) => c.nombre === nombre)?.id

  const enviarSolicitud = (e) => {
    e.preventDefault()

    if (nuevo.fechaFin < nuevo.fechaInicio) {
      setErrorSolicitud('La fecha de fin no puede ser anterior a la fecha de inicio.')
      return
    }
    setErrorSolicitud('')

    const conductorSolicitud = esConductor ? sesion?.nombre : nuevo.conductor

    setSolicitudes((prev) => [
      {
        id: prev.length + 1,
        ...nuevo,
        conductor: conductorSolicitud,
        documentoNombre: documento ? documento.name : null,
        documentoUrl: documento ? URL.createObjectURL(documento) : null,
        solicitadoEl: new Date().toLocaleDateString('es-MX'),
        estatus: 'Pendiente',
      },
      ...prev,
    ])
    registrar('crear', 'Permisos', `Nueva solicitud de ${nuevo.tipo} para ${conductorSolicitud} (${nuevo.fechaInicio} a ${nuevo.fechaFin})`)
    setNuevo({ conductor: '', tipo: 'Permiso personal', fechaInicio: '', fechaFin: '', motivo: '' })
    setDocumento(null)
    setMostrarForm(false)
    setErrorSolicitud('')
  }

  const descargarPDF = () => {
    setTimeout(() => exportarComoPDF('permisos-listado.pdf'), 50)
  }

  const descargarExcel = () => {
    const filas = solicitudesFiltradas.map((s) => ({
      Conductor: s.conductor,
      Tipo: s.tipo,
      'Fecha inicio': s.fechaInicio,
      'Fecha fin': s.fechaFin,
      Motivo: s.motivo,
      'Solicitado el': s.solicitadoEl,
      Estatus: s.estatus,
      'Comentario RH': s.comentarioRH ? s.comentarioRH : '',
    }))
    exportarAExcel(filas, 'permisos-listado.xlsx')
  }

  return (
    <AppLayout>
      <div className="space-y-4 md:space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h1 className="flex items-center gap-2 text-xl font-semibold text-servitur-texto">
              <ClipboardList className="w-5 h-5 text-servitur-azul" />
              Permisos y oficios
            </h1>
            <p className="text-sm text-servitur-texto-secundario mt-0.5">
              Solicitudes de los conductores (permiso personal u oficio de comisión) y su aprobación por RH.
            </p>
          </div>
          {tab === 'solicitudes' && (
            <button
              onClick={() => setMostrarForm(!mostrarForm)}
              className="flex items-center gap-1.5 text-sm bg-servitur-azul hover:opacity-90 text-white px-3 py-2 rounded-lg self-start"
            >
              <Plus className="w-4 h-4" /> Nueva solicitud
            </button>
          )}
        </div>

        <div className="flex gap-2 border-b border-servitur-texto-secundario/15">
          <button
            onClick={() => setTab('solicitudes')}
            className={
              tab === 'solicitudes'
                ? 'px-4 py-2.5 text-sm font-medium border-b-2 -mb-px transition-colors border-servitur-rojo text-servitur-rojo'
                : 'px-4 py-2.5 text-sm font-medium border-b-2 -mb-px transition-colors border-transparent text-servitur-texto-secundario hover:text-servitur-texto'
            }
          >
            Solicitudes de permiso
          </button>
          <button
            onClick={() => setTab('incidencias')}
            className={
              tab === 'incidencias'
                ? 'px-4 py-2.5 text-sm font-medium border-b-2 -mb-px transition-colors border-servitur-rojo text-servitur-rojo'
                : 'px-4 py-2.5 text-sm font-medium border-b-2 -mb-px transition-colors border-transparent text-servitur-texto-secundario hover:text-servitur-texto'
            }
          >
            Retrasos e incidencias
          </button>
        </div>

        {tab === 'incidencias' ? (
          <IncidenciasPanel />
        ) : (
          <div>
            <div className="grid grid-cols-3 gap-3 mb-4 md:mb-6">
              <div className="bg-servitur-tarjeta rounded-xl shadow-sm border border-servitur-texto-secundario/10 p-3 text-center">
                <p className="text-xl font-semibold text-servitur-texto">{conteo.Pendiente}</p>
                <span className="inline-block mt-1 px-2 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-700">
                  Pendiente
                </span>
              </div>
              <div className="bg-servitur-tarjeta rounded-xl shadow-sm border border-servitur-texto-secundario/10 p-3 text-center">
                <p className="text-xl font-semibold text-servitur-texto">{conteo.Aprobado}</p>
                <span className="inline-block mt-1 px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-700">
                  Aprobado
                </span>
              </div>
              <div className="bg-servitur-tarjeta rounded-xl shadow-sm border border-servitur-texto-secundario/10 p-3 text-center">
                <p className="text-xl font-semibold text-servitur-texto">{conteo.Rechazado}</p>
                <span className="inline-block mt-1 px-2 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-700">
                  Rechazado
                </span>
              </div>
            </div>

            {mostrarForm && (
              <form
                onSubmit={enviarSolicitud}
                className="bg-servitur-tarjeta rounded-xl shadow-sm border border-servitur-texto-secundario/10 p-4 md:p-6 grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4 md:mb-6"
              >
                <div>
                  <label className="block text-sm font-medium text-servitur-texto mb-1">Conductor</label>
                  {esConductor ? (
                    <input
                      type="text"
                      readOnly
                      value={sesion?.nombre ?? ''}
                      className="w-full border border-servitur-texto-secundario/30 rounded-lg px-3 py-2.5 text-sm bg-servitur-fondo text-servitur-texto-secundario"
                    />
                  ) : (
                    <input
                      required
                      type="text"
                      value={nuevo.conductor}
                      onChange={(e) => setNuevo({ ...nuevo, conductor: e.target.value })}
                      className="w-full border border-servitur-texto-secundario/30 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-servitur-azul"
                    />
                  )}
                </div>
                <div>
                  <label className="block text-sm font-medium text-servitur-texto mb-1">Tipo de solicitud</label>
                  <select
                    value={nuevo.tipo}
                    onChange={(e) => setNuevo({ ...nuevo, tipo: e.target.value })}
                    className="w-full border border-servitur-texto-secundario/30 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-servitur-azul"
                  >
                    <option>Permiso personal</option>
                    <option>Oficio de comisión</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-servitur-texto mb-1">Fecha de inicio</label>
                  <input
                    required
                    type="date"
                    value={nuevo.fechaInicio}
                    onChange={(e) => setNuevo({ ...nuevo, fechaInicio: e.target.value })}
                    className="w-full border border-servitur-texto-secundario/30 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-servitur-azul"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-servitur-texto mb-1">Fecha de fin</label>
                  <input
                    required
                    type="date"
                    min={nuevo.fechaInicio || undefined}
                    value={nuevo.fechaFin}
                    onChange={(e) => setNuevo({ ...nuevo, fechaFin: e.target.value })}
                    className="w-full border border-servitur-texto-secundario/30 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-servitur-azul"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-sm font-medium text-servitur-texto mb-1">Motivo</label>
                  <textarea
                    required
                    rows={2}
                    value={nuevo.motivo}
                    onChange={(e) => setNuevo({ ...nuevo, motivo: e.target.value })}
                    className="w-full border border-servitur-texto-secundario/30 rounded-lg px-3 py-2.5 text-sm outline-none focus:border-servitur-azul resize-none"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-sm font-medium text-servitur-texto mb-1">Documento de soporte (opcional)</label>
                  <input
                    type="file"
                    accept="image/*,.pdf"
                    onChange={(e) => setDocumento(e.target.files[0] ? e.target.files[0] : null)}
                    className="w-full text-sm border border-servitur-texto-secundario/30 rounded-lg px-3 py-2 outline-none focus:border-servitur-azul"
                  />
                  <p className="text-xs text-servitur-texto-secundario mt-1">
                    Por ejemplo, la constancia de una cita médica o el comprobante del trámite.
                  </p>
                </div>
                <div className="sm:col-span-2 flex items-center justify-between gap-3">
                  {errorSolicitud ? (
                    <p className="text-sm text-servitur-rojo">{errorSolicitud}</p>
                  ) : (
                    <span />
                  )}
                  <button type="submit" className="bg-servitur-azul text-white text-sm font-medium px-5 py-2.5 rounded-lg hover:opacity-90">
                    Enviar solicitud
                  </button>
                </div>
              </form>
            )}

            <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-4 md:mb-6">
              <div className="flex items-center gap-2 border border-servitur-texto-secundario/30 rounded-lg px-3 py-2 bg-servitur-tarjeta flex-1">
                <Search className="w-4 h-4 text-servitur-texto-secundario" />
                <input
                  type="text"
                  value={filtroConductor}
                  onChange={(e) => setFiltroConductor(e.target.value)}
                  placeholder="Buscar por conductor..."
                  className="outline-none text-sm bg-transparent w-full"
                />
              </div>
              <select
                value={filtroEstatus}
                onChange={(e) => setFiltroEstatus(e.target.value)}
                className="border border-servitur-texto-secundario/30 rounded-lg px-3 py-2 text-sm outline-none bg-servitur-tarjeta focus:border-servitur-azul"
              >
                {ESTATUS_FILTRO.map((e) => (
                  <option key={e} value={e}>{e}</option>
                ))}
              </select>
              <div className="flex items-center gap-2">
                <button
                  onClick={descargarPDF}
                  className="flex items-center gap-1.5 text-sm border border-servitur-azul text-servitur-azul px-3 py-2 rounded-lg hover:bg-servitur-azul/5"
                >
                  <FileDown className="w-4 h-4" /> PDF
                </button>
                <button
                  onClick={descargarExcel}
                  className="flex items-center gap-1.5 text-sm border border-green-700 text-green-700 px-3 py-2 rounded-lg hover:bg-green-50"
                >
                  <FileSpreadsheet className="w-4 h-4" /> Excel
                </button>
              </div>
            </div>

            <div className="bg-servitur-tarjeta rounded-xl shadow-sm border border-servitur-texto-secundario/10 overflow-x-auto">
              {solicitudesFiltradas.length === 0 ? (
                <EmptyState
                  titulo="No hay solicitudes con estos filtros"
                  descripcion="Prueba con otro nombre de conductor o cambia el estatus seleccionado."
                  onLimpiar={() => {
                    setFiltroConductor('')
                    setFiltroEstatus('Todos')
                  }}
                />
              ) : (
                <table className="w-full text-sm min-w-[780px]">
                  <thead>
                    <tr className="text-left text-servitur-texto-secundario border-b border-servitur-texto-secundario/15">
                      <th className="font-medium py-3 px-4">Conductor</th>
                      <th className="font-medium py-3 px-2">Tipo</th>
                      <th className="font-medium py-3 px-2">Periodo</th>
                      <th className="font-medium py-3 px-2">Motivo</th>
                      <th className="font-medium py-3 px-2">Solicitado el</th>
                      <th className="font-medium py-3 px-2">Estatus</th>
                      <th className="font-medium py-3 px-4">RH</th>
                    </tr>
                  </thead>
                  <tbody>
                    {solicitudesFiltradas.map((s) => {
                      const idConductor = buscarIdConductor(s.conductor)

                      let celdaConductor
                      if (idConductor) {
                        celdaConductor = (
                          <Link to={'/usuarios/' + idConductor} className="text-servitur-azul hover:underline">
                            {s.conductor}
                          </Link>
                        )
                      } else {
                        celdaConductor = <span className="text-servitur-texto">{s.conductor}</span>
                      }

                      let celdaAdjunto = null
                      if (s.documentoUrl) {
                        celdaAdjunto = (
                          <a
                            href={s.documentoUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="flex items-center gap-1 text-xs text-servitur-azul hover:underline mt-0.5"
                          >
                            <Paperclip className="w-3 h-3" />
                            {s.documentoNombre}
                          </a>
                        )
                      }

                      let celdaComentario = null
                      if (s.comentarioRH) {
                        celdaComentario = (
                          <p className="text-xs text-servitur-texto-secundario mt-1 max-w-[160px]" title={s.comentarioRH}>
                            {s.comentarioRH}
                          </p>
                        )
                      }

                      let celdaAcciones
                      if (rechazandoId === s.id) {
                        celdaAcciones = (
                          <div className="flex flex-col gap-1.5 min-w-[180px]">
                            <textarea
                              autoFocus
                              rows={2}
                              value={comentarioRechazo}
                              onChange={(e) => setComentarioRechazo(e.target.value)}
                              placeholder="Motivo del rechazo (opcional)"
                              className="w-full border border-servitur-texto-secundario/30 rounded-lg px-2 py-1.5 text-xs outline-none focus:border-servitur-azul resize-none"
                            />
                            <div className="flex items-center gap-2">
                              <button onClick={() => confirmarRechazo(s.id)} className="text-xs text-servitur-rojo hover:underline">
                                Confirmar rechazo
                              </button>
                              <button onClick={() => setRechazandoId(null)} className="text-xs text-servitur-texto-secundario hover:underline">
                                Cancelar
                              </button>
                            </div>
                          </div>
                        )
                      } else if (s.estatus === 'Pendiente' || editandoId === s.id) {
                        if (puedeGestionar) {
                          celdaAcciones = (
                            <div className="flex items-center gap-2">
                              <button onClick={() => aprobar(s.id)} className="flex items-center gap-1 text-xs text-green-700 hover:underline">
                                <Check className="w-3.5 h-3.5" /> Aprobar
                              </button>
                              <button onClick={() => iniciarRechazo(s.id)} className="flex items-center gap-1 text-xs text-servitur-rojo hover:underline">
                                <XIcon className="w-3.5 h-3.5" /> Rechazar
                              </button>
                              {editandoId === s.id && (
                                <button onClick={() => setEditandoId(null)} className="text-xs text-servitur-texto-secundario hover:underline">
                                  Cancelar
                                </button>
                              )}
                            </div>
                          )
                        } else {
                          celdaAcciones = (
                            <span className="flex items-center gap-1 text-xs text-servitur-texto-secundario">
                              <Lock className="w-3.5 h-3.5" /> Solo RH / supervisores
                            </span>
                          )
                        }
                      } else if (puedeGestionar) {
                        celdaAcciones = (
                          <button onClick={() => setEditandoId(s.id)} className="flex items-center gap-1 text-xs text-servitur-azul hover:underline">
                            <Pencil className="w-3.5 h-3.5" /> Editar
                          </button>
                        )
                      } else {
                        celdaAcciones = <span className="text-xs text-servitur-texto-secundario">—</span>
                      }

                      return (
                        <tr key={s.id} className="border-b border-servitur-texto-secundario/10 last:border-0">
                          <td className="py-2.5 px-4 font-medium">{celdaConductor}</td>
                          <td className="py-2.5 px-2 text-servitur-texto-secundario">{s.tipo}</td>
                          <td className="py-2.5 px-2 text-servitur-texto-secundario">{s.fechaInicio} - {s.fechaFin}</td>
                          <td className="py-2.5 px-2 text-servitur-texto-secundario max-w-xs">
                            <span className="truncate block" title={s.motivo}>{s.motivo}</span>
                            {celdaAdjunto}
                          </td>
                          <td className="py-2.5 px-2 text-servitur-texto-secundario">{s.solicitadoEl}</td>
                          <td className="py-2.5 px-2">
                            <span className={'px-2.5 py-1 rounded-full text-xs font-medium ' + ESTATUS_STYLES[s.estatus]}>
                              {s.estatus}
                            </span>
                            {celdaComentario}
                          </td>
                          <td className="py-2.5 px-4">{celdaAcciones}</td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        )}
      </div>

      <div className="print-area">
        <PermisosListPrintable solicitudes={solicitudesFiltradas} />
      </div>
    </AppLayout>
  )
}