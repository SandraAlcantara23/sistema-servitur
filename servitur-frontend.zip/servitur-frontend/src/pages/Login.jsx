import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { User, Lock, UserCog, AlertTriangle, BadgeCheck } from 'lucide-react'
import logo from '../assets/logo.jpeg'
import busHero from '../assets/bus-hero.png'
import { useAuth } from '../context/AuthContext.jsx'
import { ROLES, RUTA_INICIO_POR_ROL } from '../utils/rolesPermisos.js'
import { conductores } from '../data/conductoresMock.js'
import { buscarUsuarioPorCorreo } from '../utils/usuariosRegistrados.js'
import { registrarEvento } from '../utils/bitacora.js'

export default function Login() {
  const [correo, setCorreo] = useState('')
  const [contrasena, setContrasena] = useState('')
  const [rol, setRol] = useState(ROLES[0])
  const [conductorId, setConductorId] = useState('')
  const [cuentaEncontrada, setCuentaEncontrada] = useState(null)
  const [error, setError] = useState('')
  const navigate = useNavigate()
  const { iniciarSesion } = useAuth()

  const revisarCorreo = () => {
    const cuenta = buscarUsuarioPorCorreo(correo)
    setCuentaEncontrada(cuenta)
    if (cuenta) setRol(cuenta.rol)
  }

  const handleSubmit = (e) => {
    e.preventDefault()

    const correoLimpio = correo.trim()
    const correoValido = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correoLimpio)
    if (!correoValido) {
      setError('Ingresa un correo electrónico válido.')
      return
    }
    setError('')

    // TODO: reemplazar por la llamada real al backend (Django REST Framework),
    // que debe validar correo + contraseña y devolver el nombre y rol reales.
    // Mientras tanto, buscamos si ese correo ya se registró (ver
    // usuariosRegistrados.js) para mostrar su nombre real; si no se
    // encuentra, el selector de "Rol" de abajo sirve como respaldo de
    // demostración.
    const cuenta = buscarUsuarioPorCorreo(correoLimpio)
    const rolFinal = cuenta?.rol ?? rol
    const conductorSeleccionado = conductores.find((c) => String(c.id) === conductorId)

    const nombreFinal =
      rolFinal === 'Conductor'
        ? conductorSeleccionado?.nombre ?? cuenta?.nombre ?? correoLimpio
        : cuenta?.nombre ?? correoLimpio

    iniciarSesion({ nombre: nombreFinal, rol: rolFinal, correo: correoLimpio })
    registrarEvento({
      usuario: nombreFinal,
      rol: rolFinal,
      accion: 'iniciar_sesion',
      modulo: 'Sesión',
      detalle: `Inició sesión (${correoLimpio})`,
    })
    navigate(RUTA_INICIO_POR_ROL[rolFinal] ?? '/dashboard')
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-servitur-fondo p-4">
      <div className="w-full max-w-4xl bg-servitur-tarjeta rounded-2xl shadow-xl overflow-hidden grid grid-cols-1 md:grid-cols-2">
        {/* Banner del camión en móvil — arriba del formulario */}
        <div className="md:hidden h-40 sm:h-48 overflow-hidden">
          <img
            src={busHero}
            alt="Autobús Servitur Gran Clas"
            className="w-full h-full object-cover"
          />
        </div>

        {/* Panel izquierdo — foto real del camión, lado a lado en tablet/desktop */}
        <div className="relative hidden md:flex items-center justify-center bg-servitur-azul-oscuro overflow-hidden">
          <img
            src={busHero}
            alt="Autobús Servitur Gran Clas"
            className="w-full h-full object-contain"
          />
        </div>

        {/* Panel derecho — formulario */}
        <div className="flex flex-col justify-center px-6 py-10 sm:px-10 md:px-12 md:py-12">
          <div className="text-center mb-8">
            <img
              src={logo}
              alt="Servitur Gran Clas — Calidad y Seguridad a su Servicio"
              className="mx-auto w-64 sm:w-72"
            />
          </div>

          <p className="text-servitur-texto-secundario text-sm mb-6">
            Ingresa tus credenciales para acceder al sistema.
          </p>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label htmlFor="correo" className="block text-servitur-texto font-medium mb-1.5">
                Correo electrónico:
              </label>
              <div className="flex items-center border border-servitur-texto-secundario/40 rounded-lg px-3 focus-within:border-servitur-azul focus-within:ring-1 focus-within:ring-servitur-azul">
                <User className="w-5 h-5 text-servitur-texto-secundario shrink-0" />
                <input
                  id="correo"
                  type="email"
                  value={correo}
                  onChange={(e) => {
                    setCorreo(e.target.value)
                    if (cuentaEncontrada) setCuentaEncontrada(null)
                  }}
                  onBlur={revisarCorreo}
                  placeholder="correo@servitur.com"
                  className="w-full px-3 py-3 text-base outline-none bg-transparent text-servitur-texto placeholder:text-servitur-texto-secundario/60"
                  required
                />
              </div>
              {cuentaEncontrada && (
                <p className="flex items-center gap-1.5 text-xs text-green-700 mt-1.5">
                  <BadgeCheck className="w-3.5 h-3.5 shrink-0" />
                  Cuenta encontrada: {cuentaEncontrada.nombre} ({cuentaEncontrada.rol})
                </p>
              )}
            </div>

            <div>
              <label htmlFor="contrasena" className="block text-servitur-texto font-medium mb-1.5">
                Contraseña:
              </label>
              <div className="flex items-center border border-servitur-texto-secundario/40 rounded-lg px-3 focus-within:border-servitur-azul focus-within:ring-1 focus-within:ring-servitur-azul">
                <Lock className="w-5 h-5 text-servitur-texto-secundario shrink-0" />
                <input
                  id="contrasena"
                  type="password"
                  value={contrasena}
                  onChange={(e) => setContrasena(e.target.value)}
                  placeholder="Contraseña"
                  className="w-full px-3 py-3 text-base outline-none bg-transparent text-servitur-texto placeholder:text-servitur-texto-secundario/60"
                  required
                />
              </div>
            </div>

            <div className="flex items-start gap-2 bg-amber-50 border border-amber-300 rounded-lg px-3 py-2.5">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <p className="text-xs text-amber-800 leading-relaxed">
                <span className="font-semibold">Modo de prueba.</span> El selector de rol de aquí abajo es solo para
                simular sesiones mientras no hay backend — no valida usuario/contraseña reales. Cuando se conecte
                Django, el rol vendrá determinado por el servidor, no por lo que se elija aquí.
              </p>
            </div>

            <div>
              <label htmlFor="rol" className="block text-servitur-texto font-medium mb-1.5">
                Rol <span className="text-xs font-normal text-servitur-texto-secundario">(temporal, para pruebas)</span>
              </label>
              <div className="flex items-center border border-servitur-texto-secundario/40 rounded-lg px-3 focus-within:border-servitur-azul focus-within:ring-1 focus-within:ring-servitur-azul">
                <UserCog className="w-5 h-5 text-servitur-texto-secundario shrink-0" />
                <select
                  id="rol"
                  value={rol}
                  onChange={(e) => setRol(e.target.value)}
                  className="w-full px-3 py-3 text-base outline-none bg-transparent text-servitur-texto"
                >
                  {ROLES.map((r) => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
              </div>
            </div>

            {rol === 'Conductor' && (
              <div>
                <label htmlFor="conductor" className="block text-servitur-texto font-medium mb-1.5">
                  ¿Qué conductor eres? <span className="text-xs font-normal text-servitur-texto-secundario">(demo)</span>
                </label>
                <select
                  id="conductor"
                  required
                  value={conductorId}
                  onChange={(e) => setConductorId(e.target.value)}
                  className="w-full border border-servitur-texto-secundario/40 rounded-lg px-3 py-3 text-base outline-none focus:border-servitur-azul bg-transparent text-servitur-texto"
                >
                  <option value="" disabled>Selecciona tu nombre</option>
                  {conductores.map((c) => (
                    <option key={c.id} value={c.id}>{c.nombre}</option>
                  ))}
                </select>
              </div>
            )}

            {error && <p className="text-sm text-servitur-rojo">{error}</p>}

            <button
              type="submit"
              className="w-full bg-servitur-rojo hover:bg-servitur-rojo-hover text-white font-semibold py-3 rounded-lg transition-colors duration-200 mt-2"
            >
              Iniciar Sesión
            </button>
          </form>

          <p className="text-center text-sm text-servitur-texto-secundario mt-4">
            ¿No tienes cuenta?{' '}
            <Link to="/registro" className="text-servitur-azul font-medium hover:underline">
              Regístrate
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}