"""
core/views.py
"""
from rest_framework import viewsets, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import (
    Rol,
    Usuario,
    Conductor,
    Unidad,
    Ruta,
    Turno,
    Servicio,
    Aforo,
    Mantenimiento,
    Permiso,
    BitacoraAuditoria,
)
from .serializers import (
    RolSerializer,
    UsuarioSerializer,
    ConductorSerializer,
    UnidadSerializer,
    RutaSerializer,
    TurnoSerializer,
    ServicioSerializer,
    AforoSerializer,
    MantenimientoSerializer,
    PermisoSerializer,
    BitacoraAuditoriaSerializer,
)
from .permissions import (
    EsAdministrador,
    EsAdminOSupervisor,
    EsPersonalOperativo,
    EsRH,
    EsConductor,
)


def registrar_bitacora(usuario, accion, entidad_afectada):
    BitacoraAuditoria.objects.create(
        usuario=usuario, accion=accion, entidad_afectada=entidad_afectada
    )


def _es_admin_o_supervisor(request):
    user = request.user
    return bool(
        user.is_authenticated and user.rol and user.rol.nombre in ("Administrador", "Supervisor")
    )


class RolViewSet(viewsets.ModelViewSet):
    """Solo Administrador puede ver/gestionar roles."""

    queryset = Rol.objects.all()
    serializer_class = RolSerializer
    permission_classes = [EsAdministrador]


class UsuarioViewSet(viewsets.ModelViewSet):
    queryset = Usuario.objects.select_related("rol").all()
    serializer_class = UsuarioSerializer
    permission_classes = [EsAdminOSupervisor]

    def get_queryset(self):
        # Cada quien puede ver/editar su propio usuario aunque no sea Admin/Supervisor
        if self.action in ("retrieve", "update", "partial_update") and not _es_admin_o_supervisor(self.request):
            return Usuario.objects.filter(pk=self.request.user.pk)
        return super().get_queryset()

    def get_permissions(self):
        if self.action in ("retrieve", "update", "partial_update"):
            return [permissions.IsAuthenticated()]
        return super().get_permissions()


class ConductorViewSet(viewsets.ModelViewSet):
    queryset = Conductor.objects.select_related("usuario").all()
    serializer_class = ConductorSerializer
    permission_classes = [EsPersonalOperativo | EsRH]


class UnidadViewSet(viewsets.ModelViewSet):
    queryset = Unidad.objects.all()
    serializer_class = UnidadSerializer
    permission_classes = [EsPersonalOperativo]


class RutaViewSet(viewsets.ModelViewSet):
    queryset = Ruta.objects.all()
    serializer_class = RutaSerializer
    permission_classes = [EsPersonalOperativo]


class TurnoViewSet(viewsets.ModelViewSet):
    queryset = Turno.objects.all()
    serializer_class = TurnoSerializer
    permission_classes = [EsPersonalOperativo]


class ServicioViewSet(viewsets.ModelViewSet):
    queryset = Servicio.objects.select_related("conductor", "unidad", "ruta", "turno").all()
    serializer_class = ServicioSerializer
    permission_classes = [EsPersonalOperativo]


class AforoViewSet(viewsets.ModelViewSet):
    """Personal operativo ve todo; un Conductor solo ve/crea lo suyo."""

    serializer_class = AforoSerializer
    permission_classes = [EsPersonalOperativo | EsConductor]

    def get_queryset(self):
        qs = Aforo.objects.select_related("ruta", "turno", "registrado_por").all()
        user = self.request.user
        if user.rol and user.rol.nombre in ("Administrador", "Supervisor", "Monitoreo"):
            return qs
        return qs.filter(registrado_por=user)

    def perform_create(self, serializer):
        aforo = serializer.save(registrado_por=self.request.user)
        registrar_bitacora(self.request.user, "crear", f"Aforo #{aforo.id}")


class MantenimientoViewSet(viewsets.ModelViewSet):
    queryset = Mantenimiento.objects.select_related("unidad").all()
    serializer_class = MantenimientoSerializer
    permission_classes = [EsPersonalOperativo]


class PermisoViewSet(viewsets.ModelViewSet):
    """
    Administrador/Supervisor y RH ven y autorizan/rechazan todo.
    Un Conductor solo ve/crea sus propias solicitudes (personal u oficio de
    comisión), con rango de fechas, motivo y un documento de soporte opcional.
    """

    serializer_class = PermisoSerializer
    permission_classes = [EsAdminOSupervisor | EsRH | EsConductor]

    def get_serializer_context(self):
        # Necesario para que documento_url arme una URL absoluta.
        return {**super().get_serializer_context(), "request": self.request}

    def get_queryset(self):
        qs = Permiso.objects.select_related("conductor__usuario", "autorizado_por").all()
        user = self.request.user
        if user.rol and user.rol.nombre in ("Administrador", "Supervisor", "RH"):
            return qs
        # Conductor: solo lo suyo
        return qs.filter(conductor__usuario=user)

    def perform_create(self, serializer):
        conductor = getattr(self.request.user, "conductor", None)
        if conductor is not None:
            permiso = serializer.save(conductor=conductor)
        else:
            permiso = serializer.save()
        registrar_bitacora(self.request.user, "crear", f"Permiso #{permiso.id}")

    @action(detail=True, methods=["post"], permission_classes=[EsAdminOSupervisor | EsRH])
    def autorizar(self, request, pk=None):
        permiso = self.get_object()
        permiso.estado = Permiso.Estado.AUTORIZADO
        permiso.comentario_rechazo = ""
        permiso.autorizado_por = request.user
        permiso.save()
        registrar_bitacora(request.user, "autorizar", f"Permiso #{permiso.id}")
        return Response(PermisoSerializer(permiso, context={"request": request}).data)

    @action(detail=True, methods=["post"], permission_classes=[EsAdminOSupervisor | EsRH])
    def rechazar(self, request, pk=None):
        permiso = self.get_object()
        permiso.estado = Permiso.Estado.RECHAZADO
        permiso.comentario_rechazo = request.data.get("comentario", "")
        permiso.autorizado_por = request.user
        permiso.save()
        registrar_bitacora(request.user, "rechazar", f"Permiso #{permiso.id}")
        return Response(PermisoSerializer(permiso, context={"request": request}).data)


class BitacoraAuditoriaViewSet(viewsets.ReadOnlyModelViewSet):
    """Solo lectura: el registro lo crea el sistema, no se edita a mano."""

    queryset = BitacoraAuditoria.objects.select_related("usuario").all()
    serializer_class = BitacoraAuditoriaSerializer
    permission_classes = [EsAdminOSupervisor]


class MeView(APIView):
    """
    GET /api/me/  -> datos del usuario autenticado (rol, nombre, y su
    conductor_id si aplica). El frontend la llama justo después del login
    para saber a dónde mandar al usuario y qué mostrarle según su rol.
    """

    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        user = request.user
        conductor = getattr(user, "conductor", None)
        return Response({
            "id": user.id,
            "username": user.username,
            "nombre": user.get_full_name() or user.username,
            "email": user.email,
            "rol": user.rol.nombre if user.rol else None,
            "conductor_id": conductor.id if conductor else None,
        })
