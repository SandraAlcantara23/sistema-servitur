"""
core/models.py

Modelos de Django para el Sistema Web Servitur.
Corresponden 1:1 al modelo entidad-relación de la Actividad 2 (11 entidades).

Notas de integración:
- Usuario extiende AbstractUser: agrégalo como AUTH_USER_MODEL en settings.py:
    AUTH_USER_MODEL = "core.Usuario"
  (debe hacerse ANTES de la primera migración; si el proyecto ya tiene
  migraciones con el User por defecto, este cambio requiere migrar desde cero
  o un proceso de migración de usuario personalizado.)
- Todas las tablas usan el "id" autogenerado de Django como PK
  (equivalente a id_rol, id_usuario, etc. del diagrama ER).
- Los ForeignKey usan PROTECT donde borrar el registro padre no debería
  borrar en cascada datos operativos (evita perder historial); usa CASCADE
  donde sí tiene sentido (p. ej. Conductor -> Usuario).
"""

from django.contrib.auth.models import AbstractUser
from django.db import models


class Rol(models.Model):
    """Administrador, Supervisor, Monitoreo, RH, Conductor."""

    nombre = models.CharField(max_length=30, unique=True)

    class Meta:
        verbose_name = "Rol"
        verbose_name_plural = "Roles"

    def __str__(self):
        return self.nombre


class Usuario(AbstractUser):
    """Usuario del sistema. Sustituye al User por defecto de Django."""

    rol = models.ForeignKey(Rol, on_delete=models.PROTECT, related_name="usuarios")
    activo = models.BooleanField(default=True)

    def __str__(self):
        return self.get_full_name() or self.username


class Conductor(models.Model):
    usuario = models.OneToOneField(
        Usuario, on_delete=models.CASCADE, related_name="conductor"
    )
    clave = models.CharField(max_length=20, unique=True)
    licencia = models.CharField(max_length=30)
    vigencia_licencia = models.DateField()
    domicilio = models.CharField(max_length=255)

    def __str__(self):
        return f"{self.usuario.get_full_name()} ({self.clave})"


class Unidad(models.Model):
    class Tipo(models.TextChoices):
        AUTOBUS = "autobus", "Autobús"
        CAMIONETA = "camioneta", "Camioneta/Van"

    eco = models.CharField(max_length=4, unique=True)
    placas = models.CharField(max_length=15)
    tipo = models.CharField(max_length=15, choices=Tipo.choices)
    tecnologia = models.CharField(max_length=50)
    rendimiento = models.DecimalField(
        max_digits=6, decimal_places=2, null=True, blank=True,
        help_text="Editado manualmente; ya no se calcula automáticamente.",
    )
    recorrido = models.PositiveIntegerField(default=0)

    def __str__(self):
        return f"ECO {self.eco}"


class Ruta(models.Model):
    class TipoCamino(models.TextChoices):
        AUTOPISTA = "autopista", "Autopista"
        NORMAL = "normal", "Carretera normal"

    nombre = models.CharField(max_length=50, unique=True)
    tipo_camino = models.CharField(max_length=15, choices=TipoCamino.choices)

    def __str__(self):
        return self.nombre


class Turno(models.Model):
    """
    1er/2do/3er turno (entrada o salida) y Turno mixto (entrada o salida).
    Ej. nombre="1er turno - entrada".
    """

    nombre = models.CharField(max_length=40, unique=True)
    hora_entrada = models.TimeField(null=True, blank=True)
    hora_salida = models.TimeField(null=True, blank=True)

    def __str__(self):
        return self.nombre


class Servicio(models.Model):
    """Asignación de conductor + unidad a una ruta/turno/fecha."""

    conductor = models.ForeignKey(
        Conductor, on_delete=models.PROTECT, related_name="servicios"
    )
    unidad = models.ForeignKey(
        Unidad, on_delete=models.PROTECT, related_name="servicios"
    )
    ruta = models.ForeignKey(Ruta, on_delete=models.PROTECT, related_name="servicios")
    turno = models.ForeignKey(
        Turno, on_delete=models.PROTECT, related_name="servicios"
    )
    fecha = models.DateField()

    class Meta:
        unique_together = ("unidad", "ruta", "turno", "fecha")

    def __str__(self):
        return f"{self.ruta} · {self.fecha}"


class Aforo(models.Model):
    """Registro manual, acumulado por ruta y fecha (no por viaje individual)."""

    ruta = models.ForeignKey(Ruta, on_delete=models.PROTECT, related_name="aforos")
    turno = models.ForeignKey(Turno, on_delete=models.PROTECT, related_name="aforos")
    fecha = models.DateField()
    pasajeros_ida = models.PositiveSmallIntegerField(default=0)
    pasajeros_vuelta = models.PositiveSmallIntegerField(default=0)
    registrado_por = models.ForeignKey(
        Usuario, on_delete=models.PROTECT, related_name="aforos_registrados"
    )

    class Meta:
        unique_together = ("ruta", "turno", "fecha")
        verbose_name_plural = "Aforos"

    def __str__(self):
        return f"Aforo {self.ruta} · {self.fecha}"


class Mantenimiento(models.Model):
    """Registro administrativo simple: categoría + descripción."""

    unidad = models.ForeignKey(
        Unidad, on_delete=models.CASCADE, related_name="mantenimientos"
    )
    categoria = models.CharField(max_length=50)
    descripcion = models.TextField()
    fecha = models.DateField()

    def __str__(self):
        return f"{self.unidad} · {self.categoria} ({self.fecha})"


class Permiso(models.Model):
    """
    Solicitud de permiso personal u oficio de comisión hecha por un conductor,
    con rango de fechas, motivo y un documento de soporte opcional (constancia
    médica, comprobante de trámite, etc.). RH/Administrador/Supervisor la
    aprueban o rechazan (con comentario opcional en el rechazo).
    """

    class Tipo(models.TextChoices):
        PERSONAL = "personal", "Permiso personal"
        OFICIO = "oficio", "Oficio de comisión"

    class Estado(models.TextChoices):
        PENDIENTE = "pendiente", "Pendiente"
        AUTORIZADO = "autorizado", "Aprobado"
        RECHAZADO = "rechazado", "Rechazado"

    conductor = models.ForeignKey(
        Conductor, on_delete=models.CASCADE, related_name="permisos"
    )
    tipo = models.CharField(max_length=15, choices=Tipo.choices)
    fecha_inicio = models.DateField(null=True, blank=True)
    fecha_fin = models.DateField(null=True, blank=True)
    motivo = models.TextField(blank=True, default="")
    documento = models.FileField(upload_to="permisos/", null=True, blank=True)
    estado = models.CharField(
        max_length=15, choices=Estado.choices, default=Estado.PENDIENTE
    )
    comentario_rechazo = models.TextField(blank=True, default="")
    autorizado_por = models.ForeignKey(
        Usuario,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="permisos_autorizados",
    )
    creado = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-creado"]

    def __str__(self):
        return f"{self.conductor} · {self.tipo} ({self.estado})"


class BitacoraAuditoria(models.Model):
    """Registro automático de acciones de usuarios (no la bitácora de Excel)."""

    usuario = models.ForeignKey(
        Usuario, on_delete=models.SET_NULL, null=True, related_name="acciones"
    )
    accion = models.CharField(max_length=100)
    entidad_afectada = models.CharField(max_length=100)
    fecha = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = "Bitácora de auditoría"
        ordering = ["-fecha"]

    def __str__(self):
        return f"{self.usuario} · {self.accion} ({self.fecha:%Y-%m-%d %H:%M})"
