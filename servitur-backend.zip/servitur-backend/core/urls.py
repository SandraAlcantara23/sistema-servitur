"""
core/urls.py
"""
from django.urls import path
from rest_framework.routers import DefaultRouter

from .views import (
    RolViewSet,
    UsuarioViewSet,
    ConductorViewSet,
    UnidadViewSet,
    RutaViewSet,
    TurnoViewSet,
    ServicioViewSet,
    AforoViewSet,
    MantenimientoViewSet,
    PermisoViewSet,
    BitacoraAuditoriaViewSet,
    MeView,
)

router = DefaultRouter()
router.register("roles", RolViewSet, basename="rol")
router.register("usuarios", UsuarioViewSet, basename="usuario")
router.register("conductores", ConductorViewSet, basename="conductor")
router.register("unidades", UnidadViewSet, basename="unidad")
router.register("rutas", RutaViewSet, basename="ruta")
router.register("turnos", TurnoViewSet, basename="turno")
router.register("servicios", ServicioViewSet, basename="servicio")
router.register("aforos", AforoViewSet, basename="aforo")
router.register("mantenimientos", MantenimientoViewSet, basename="mantenimiento")
router.register("permisos", PermisoViewSet, basename="permiso")
router.register("bitacora", BitacoraAuditoriaViewSet, basename="bitacora")

urlpatterns = [
    path("me/", MeView.as_view(), name="me"),
] + router.urls