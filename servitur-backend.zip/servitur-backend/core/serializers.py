"""
core/serializers.py
"""
from rest_framework import serializers

from .models import (
    Rol,
    Usuario,
    Conductor,
    Unidad,
    Ruta,
    Turno,
    Servicio,
    Aforo,
    Mantenimiento,
    Permiso,
    BitacoraAuditoria,
)


class RolSerializer(serializers.ModelSerializer):
    class Meta:
        model = Rol
        fields = ["id", "nombre"]


class UsuarioSerializer(serializers.ModelSerializer):
    """Para listar/editar usuarios. La contraseña nunca se devuelve."""

    rol_nombre = serializers.CharField(source="rol.nombre", read_only=True)
    password = serializers.CharField(write_only=True, required=False)

    class Meta:
        model = Usuario
        fields = [
            "id", "username", "email", "first_name", "last_name",
            "rol", "rol_nombre", "activo", "is_active", "password",
        ]

    def create(self, validated_data):
        password = validated_data.pop("password", None)
        usuario = Usuario(**validated_data)
        if password:
            usuario.set_password(password)
        usuario.save()
        return usuario

    def update(self, instance, validated_data):
        password = validated_data.pop("password", None)
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        if password:
            instance.set_password(password)
        instance.save()
        return instance


class ConductorSerializer(serializers.ModelSerializer):
    nombre_completo = serializers.CharField(
        source="usuario.get_full_name", read_only=True
    )

    class Meta:
        model = Conductor
        fields = [
            "id", "usuario", "nombre_completo", "clave",
            "licencia", "vigencia_licencia", "domicilio",
        ]


class UnidadSerializer(serializers.ModelSerializer):
    class Meta:
        model = Unidad
        fields = [
            "id", "eco", "placas", "tipo", "tecnologia",
            "rendimiento", "recorrido",
        ]


class RutaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ruta
        fields = ["id", "nombre", "tipo_camino"]


class TurnoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Turno
        fields = ["id", "nombre", "hora_entrada", "hora_salida"]


class ServicioSerializer(serializers.ModelSerializer):
    class Meta:
        model = Servicio
        fields = ["id", "conductor", "unidad", "ruta", "turno", "fecha"]


class AforoSerializer(serializers.ModelSerializer):
    registrado_por = serializers.PrimaryKeyRelatedField(read_only=True)

    class Meta:
        model = Aforo
        fields = [
            "id", "ruta", "turno", "fecha",
            "pasajeros_ida", "pasajeros_vuelta", "registrado_por",
        ]


class MantenimientoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Mantenimiento
        fields = ["id", "unidad", "categoria", "descripcion", "fecha"]


class PermisoSerializer(serializers.ModelSerializer):
    """
    conductor es opcional al crear: si quien crea es un Conductor, la vista
    (perform_create) lo asigna automáticamente a su propio registro sin
    importar lo que venga en el payload; solo Admin/Supervisor/RH necesitan
    mandarlo explícitamente para dar de alta la solicitud de alguien más.
    """

    conductor_nombre = serializers.CharField(
        source="conductor.usuario.get_full_name", read_only=True
    )
    autorizado_por = serializers.PrimaryKeyRelatedField(read_only=True)
    documento_url = serializers.SerializerMethodField()

    class Meta:
        model = Permiso
        fields = [
            "id", "conductor", "conductor_nombre", "tipo",
            "fecha_inicio", "fecha_fin", "motivo", "documento", "documento_url",
            "estado", "comentario_rechazo", "autorizado_por", "creado",
        ]
        read_only_fields = ["estado", "comentario_rechazo"]
        extra_kwargs = {
            "conductor": {"required": False},
            "documento": {"write_only": True, "required": False},
        }

    def get_documento_url(self, obj):
        if not obj.documento:
            return None
        request = self.context.get("request")
        url = obj.documento.url
        return request.build_absolute_uri(url) if request else url

    def validate(self, data):
        inicio = data.get("fecha_inicio", getattr(self.instance, "fecha_inicio", None))
        fin = data.get("fecha_fin", getattr(self.instance, "fecha_fin", None))
        if inicio and fin and fin < inicio:
            raise serializers.ValidationError(
                {"fecha_fin": "La fecha de fin no puede ser anterior a la fecha de inicio."}
            )
        return data


class BitacoraAuditoriaSerializer(serializers.ModelSerializer):
    usuario_nombre = serializers.CharField(
        source="usuario.get_full_name", read_only=True
    )

    class Meta:
        model = BitacoraAuditoria
        fields = ["id", "usuario", "usuario_nombre", "accion", "entidad_afectada", "fecha"]
        read_only_fields = fields  # solo lectura, se genera automáticamente
